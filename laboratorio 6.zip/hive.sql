-- import inconveniente
CREATE TABLE inconveniente (
    inconveniente_id INT,
    orden_transporte_id INT,
    descripcion STRING,
    fecha_informe STRING,
    tipo STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE;
LOAD DATA INPATH '/user/cloudera/repartos_rene/raw/inconveniente'
INTO TABLE inconveniente;

-- import pig
CREATE TABLE pig_output (
    palabra STRING,
    frecuencia INT
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE;
LOAD DATA INPATH '/user/cloudera/repartos_rene/processed/quejas_frecuentes'
INTO TABLE pig_output;

-- promedio de puntuacion por pais, ruta resena - orden_transporte - cliente - direccion - comuna - ciudad - region - pais
SELECT AVG(res.puntuacion) AS puntuacion_promedio, p.nombre FROM resena res JOIN orden_transporte o ON res.orden_transporte_id = o.orden_transporte_id
JOIN cliente cli ON o.cliente_id = cli.cliente_id
JOIN direccion dir ON cli.direccion_id = dir.direccion_id
JOIN comuna com ON dir.comuna_id = com.comuna_id
JOIN ciudad ciu ON com.ciudad_id = ciu.ciudad_id
JOIN region reg ON ciu.region_id = reg.region_id
JOIN pais p ON reg.pais_id = p.pais_id
GROUP BY p.pais_id;

-- contar la cantidad de inconvenientes por ruta, ruta 1 - n orden_transporte 1 - n inconveniente
SELECT COUNT(i.inconveniente_id) as numero_inconvenientes, r.ruta_id FROM ruta r LEFT JOIN orden_transporte o ON r.ruta_id = o.ruta_id
LEFT JOIN inconveniente i ON o.orden_transporte_id = i.orden_transporte_id
GROUP BY r.ruta_id;

-- contar la cantidad de resenas negativas (< 3) por ruta, ruta 1 - n orden_transporte 1 - 1 resena
SELECT COUNT(r.ruta_id) as numero_resenas_negativas, r.ruta_id FROM ruta r JOIN orden_transporte o ON r.ruta_id = o.ruta_id
JOIN resena res ON o.orden_transporte_id = res.orden_transporte_id
WHERE res.puntuacion < 3
GROUP BY r.ruta_id;

-- media de retrasos mensual por ruta, ruta 1 - n orden_transporte 1 - n inconveniente
SELECT t.ruta_id, AVG(t.total_inconvenientes_mensual) AS media_inconvenientes_mensuales FROM (
    SELECT r.ruta_id, COUNT(*) AS total_inconvenientes_mensual FROM ruta r
    LEFT JOIN orden_transporte o ON r.ruta_id = o.ruta_id
    LEFT JOIN inconveniente i ON o.orden_transporte_id = i.orden_transporte_id
    -- codigo hive
    -- GROUP BY r.ruta_id, date_format(i.fecha_informe, 'yyyy-MM')
    GROUP BY r.ruta_id, EXTRACT(MONTH FROM i.fecha_informe)
) t GROUP BY t.ruta_id;

-- carga de trabajo por sucursal, sucursal 1 - n orden_transporte
SELECT COUNT(o.orden_transporte_id) AS numero_ordenes, s.nombre FROM sucursal s JOIN orden_transporte o ON s.sucursal_id = o.sucursal_id
GROUP BY s.sucursal_id;

-- relacion entre carga de trabajo y satisfaccion del cliente por sucursal, sucursal 1 - n orden_transporte 1 - 1 resena
-- vista grafica de hive entre numero_ordenes y puntuacion_promedio
SELECT s.nombre, COUNT(o.orden_transporte_id) AS numero_ordenes, AVG(res.puntuacion) AS puntuacion_promedio FROM sucursal s
JOIN orden_transporte o ON s.sucursal_id = o.sucursal_id
JOIN resena res ON o.orden_transporte_id = res.orden_transporte_id
GROUP BY s.sucursal_id;
